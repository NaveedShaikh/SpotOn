//
//  ViewController.m
//  SpotOn
//
//  Created by Naveed Shaikh on 28/07/17.
//  Copyright © 2017 Naveed Shaikh. All rights reserved.
//

#import "ViewController.h"
#import "MapViewController.h"
#import "PlacedModelObject.h"


#import "ServiceController.h"
#import "MBProgressHUD.h"

#import "Constants.h"




@interface ViewController ()<UITableViewDelegate, UITableViewDataSource, UITextFieldDelegate> {
 
    NSMutableArray *arrayResults;
    IBOutlet UITableView *tableViewLocationResults;
    PlacedModelObject *objPlaceModel;
}
    
    

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



#pragma mark SearchBar Delegates Methods


-(void)searchBar:(UISearchBar *)searchBar textDidChange:(NSString *)searchText{
    
    arrayResults = [[NSMutableArray alloc] init];
    
    [ServiceController searchAPI:searchText
                  forServicePath:@"textsearch/json?query=%@&key=%@"
                       withBlock:^(id result) {
                           NSLog(@"=%@",result);
                           
                           NSMutableDictionary *dictionaryOfPlaces= [[NSMutableDictionary alloc] init];
                           
                           dictionaryOfPlaces = [NSJSONSerialization JSONObjectWithData:result options:0 error:nil];
                           NSLog(@"%@", dictionaryOfPlaces);
                           
                           
                           if ([[dictionaryOfPlaces valueForKey:@"status"]  isEqual: @"OK"]) {
                               NSLog(@"ok");
                               [self populateSearchDataOnTable:dictionaryOfPlaces];
                               
                           }
                           else {
                               NSLog(@"no ok");
                               
                               dispatch_async(dispatch_get_main_queue(), ^{
                                   [tableViewLocationResults reloadData];
                                   [self showAlert:[dictionaryOfPlaces valueForKey:@"status"]];
                               });
                            }
                           
                       } failure:^(NSError *error) {
                           
                       }];
    }





#pragma mark TableView DataSource and Delegate Methods


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [arrayResults count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *simpleTableIdentifier = @"LocationResults";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:simpleTableIdentifier];
    
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:simpleTableIdentifier];
    }
    
    objPlaceModel = [arrayResults objectAtIndex:indexPath.row];
    
    cell.textLabel.text = objPlaceModel.stringPlaceName;
    
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath*)indexPath {
    
    objPlaceModel = [arrayResults objectAtIndex:indexPath.row];

    UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:[NSBundle mainBundle]];
    MapViewController *objMapView = [storyboard instantiateViewControllerWithIdentifier:@"MapViewID"];
    objMapView.stringPlaceID = objPlaceModel.stringPlaceID;
    
    [self.navigationController pushViewController:objMapView animated:YES];
    

}

#pragma mark Custom Methods

-(void)showAlert:(NSString*)forText {
    
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:nil
                                                                   message:forText
                                                            preferredStyle:UIAlertControllerStyleAlert];
    
    [self presentViewController:alert animated:YES completion:nil];
    
    int duration = 1;
    
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, duration * NSEC_PER_SEC), dispatch_get_main_queue(), ^{
        [alert dismissViewControllerAnimated:YES completion:nil];
    });
    
}

-(void)populateSearchDataOnTable:(NSMutableDictionary*)dictionaryForPlaces{
    
    
    dictionaryForPlaces = [[NSMutableDictionary alloc] initWithDictionary:dictionaryForPlaces];
    
    dictionaryForPlaces = [dictionaryForPlaces valueForKey:@"results"];
    
    for (NSDictionary *dc in dictionaryForPlaces) {
        
        objPlaceModel = [[PlacedModelObject alloc] initWithPlacesDetails:dc];
        [arrayResults addObject:objPlaceModel];
        
    }
    
    NSLog(@"=%@",arrayResults);
    dispatch_async(dispatch_get_main_queue(), ^{
        
        [tableViewLocationResults reloadData];
    });
    
}




@end
