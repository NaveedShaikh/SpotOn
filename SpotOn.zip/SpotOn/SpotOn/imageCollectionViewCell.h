//
//  imageCollectionViewCell.h
//  SpotOn
//
//  Created by Naveed Shaikh on 01/08/17.
//  Copyright © 2017 Naveed Shaikh. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface imageCollectionViewCell : UICollectionViewCell

@property (nonatomic,weak) IBOutlet UIImageView *imageViewCollectionCell;

@end
