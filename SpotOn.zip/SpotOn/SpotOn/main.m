//
//  main.m
//  SpotOn
//
//  Created by Naveed Shaikh on 28/07/17.
//  Copyright © 2017 Naveed Shaikh. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
