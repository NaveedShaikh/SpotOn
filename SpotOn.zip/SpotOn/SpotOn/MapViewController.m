//
//  MapViewController.m
//  SpotOn
//
//  Created by Naveed Shaikh on 28/07/17.
//  Copyright © 2017 Naveed Shaikh. All rights reserved.
//

#import "MapViewController.h"
#import <AssetsLibrary/AssetsLibrary.h>

#import "PlacedModelObject.h"

#import <SDWebImage/UIImageView+WebCache.h>
#import "UIImageView+WebCache.h"

#import "imageCollectionViewCell.h"


#import <MapKit/MapKit.h>

#import "MBProgressHUD.h"
#import "ServiceController.h"

#import "Constants.h"


//#define API_KEY  @"AIzaSyBEFyiixLJAUj7xprcckI3lo4ZjGBbbISo"

//#define API_KEY  @"AIzaSyAl6N5dKNRGzWToyqR7Al5vIa5C3A2Z_t4"



@interface MapViewController ()<MKMapViewDelegate, CLLocationManagerDelegate> {
    
    NSMutableArray *arrayOfGoogleImages;
    IBOutlet UICollectionView *collectionViewOfImages;
    PlacedModelObject *objPlaceModel;
    
    NSMutableArray *arrayForDisplayingPhotos;
    CLLocationManager *locationManager;
    
}

@property (weak, nonatomic) IBOutlet MKMapView *mapView;


@end

@implementation MapViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    
    arrayOfGoogleImages = [[NSMutableArray alloc] init];
    arrayForDisplayingPhotos = [[NSMutableArray alloc] init];

    
    
    
    [_mapView setShowsUserLocation:TRUE];
    
    locationManager = [CLLocationManager new];
    if ([locationManager respondsToSelector:@selector(requestWhenInUseAuthorization)]) {
        
        [locationManager requestWhenInUseAuthorization];
    }
    
    [locationManager startUpdatingLocation];
    
}


#pragma mark MapView Delegates:

-(void)mapView:(MKMapView*)mapView didUpdateUserLocation:(nonnull MKUserLocation *)userLocation {

    MKMapCamera *camera = [MKMapCamera cameraLookingAtCenterCoordinate:userLocation.coordinate fromEyeCoordinate:CLLocationCoordinate2DMake(userLocation.coordinate.latitude, userLocation.coordinate.longitude) eyeAltitude:10000];
    [mapView setCamera:camera animated:YES];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

-(void)viewDidAppear:(BOOL)animated {
    
    [self getPlaceDetailsWithPlaceID];
}


#pragma mark Custom Methods


-(void)showAlert:(NSString*)forText {
    
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:nil
                                                                   message:forText
                                                            preferredStyle:UIAlertControllerStyleAlert];
    
    [self presentViewController:alert animated:YES completion:nil];
    
    int duration = 1;
    
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, duration * NSEC_PER_SEC), dispatch_get_main_queue(), ^{
        [alert dismissViewControllerAnimated:YES completion:nil];
    });
    
}
-(void)getPlaceDetailsWithPlaceID {
    
    [ServiceController searchAPI:_stringPlaceID
                  forServicePath:@"details/json?placeid=%@&key=%@"
                       withBlock:^(id result) {
                           
                           
                           NSMutableDictionary *dictionaryOfPhotos= [[NSMutableDictionary alloc] init];
                           
                           dictionaryOfPhotos = [NSJSONSerialization JSONObjectWithData:result options:0 error:nil];
                           NSLog(@"%@", dictionaryOfPhotos);
                           dictionaryOfPhotos = [[dictionaryOfPhotos valueForKey:@"result"]valueForKey:@"photos"];
                           
                           for (NSDictionary *dc in dictionaryOfPhotos) {
                               
                               objPlaceModel = [[PlacedModelObject alloc] initWithPlacesDetails:dc];
                               [arrayOfGoogleImages addObject:objPlaceModel];
                               
                           }
                           
                           
                           if (arrayOfGoogleImages.count !=0){
                               
                               [self getPhotosfromPhotoReference];
                           }
                           else {
                               collectionViewOfImages.hidden = TRUE;
                               [self showAlert:@"No images could be found"];
                           }
                           dispatch_async(dispatch_get_main_queue(), ^{
                               [MBProgressHUD hideHUDForView:self.view animated:YES];
                           });
                           
                           
                       } failure:^(NSError *error) {
                           NSLog(@"err=%@",error);
                           
                       }];

}


-(void)getPhotosfromPhotoReference {
    
    collectionViewOfImages.hidden = FALSE;
    for (int i=0; i<arrayOfGoogleImages.count; i++) {
        
        objPlaceModel = [arrayOfGoogleImages objectAtIndex:i];
        
        NSString *queryStringForPhotos = [NSString stringWithFormat:@"https://maps.googleapis.com/maps/api/place/photo?maxwidth=400&photoreference=%@&key=%@",objPlaceModel.stringPlaceReference,API_KEY];
        
        [arrayForDisplayingPhotos addObject:queryStringForPhotos];
        
    }
        dispatch_async(dispatch_get_main_queue(), ^{
        
        [collectionViewOfImages reloadData];
    });
    
}

-(void)displayAlertForClickOnCollectionCell:(NSString*)forImageUrl{
    
    
    UIAlertController * alert=[UIAlertController alertControllerWithTitle:@"Save Image"
                                                                  message:@"Do you want to save Image to Gallery?"
                                                           preferredStyle:UIAlertControllerStyleActionSheet];
    
    
    UIAlertAction* saveImageAction = [UIAlertAction actionWithTitle:@"Save Image" style:UIAlertActionStyleDestructive
                                                            handler:^(UIAlertAction * action) {
                                                                //Code to save Image
                                                                
                                                                dispatch_async(dispatch_get_main_queue(), ^{
                                                                    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
                                                                });
                                                                
                                                                
                                                                UIImage * result;
                                                                
                                                                NSData * data = [NSData dataWithContentsOfURL:[NSURL URLWithString:forImageUrl]];
                                                                result = [UIImage imageWithData:data];
                                                                
                                                                
                                                                dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
                                                                    UIImageWriteToSavedPhotosAlbum(result, self, @selector(image:didFinishSavingWithError:contextInfo:), nil);
                                                                });
                                                                
                                                                
                                                                
                                                                
                                                                
                                                            }];
    UIAlertAction* cancelAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"Cancel", nil) style:UIAlertActionStyleCancel
                                                         handler:^(UIAlertAction * action) {
                                                             
                                                         }];
    
    [alert addAction:saveImageAction];
    [alert addAction:cancelAction];
    [self presentViewController:alert animated:YES completion:nil];
    
}

#pragma mark CollectionView Datasource and Delegates.

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    return arrayForDisplayingPhotos.count;
}


- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *identifier = @"Cell";
    
    imageCollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:identifier forIndexPath:indexPath];
    
    NSString *ImageURL = [arrayForDisplayingPhotos objectAtIndex:indexPath.row];


    
    [MBProgressHUD showHUDAddedTo:cell.imageViewCollectionCell animated:YES];


    [cell.imageViewCollectionCell sd_setImageWithURL:[NSURL URLWithString:ImageURL] completed:^(UIImage *image, NSError *error, SDImageCacheType cacheType, NSURL *imageURL) {
        
        if (image) {
            
            dispatch_async(dispatch_get_main_queue(), ^{
                [MBProgressHUD hideHUDForView:cell.imageViewCollectionCell animated:YES];
            });
        }
        else {
            NSLog(@"Error = %@",[error localizedDescription]);
        }

    }];
    
    
    return cell;
}



-(void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath {
    
    NSString *ImageURL = [arrayForDisplayingPhotos objectAtIndex:indexPath.row];
    [self displayAlertForClickOnCollectionCell:ImageURL];
    
}

- (void)image: (UIImage *) image didFinishSavingWithError: (NSError *) error contextInfo: (void *) contextInfo {

    
    if (!error) {
        
        [self showAlert:@"Image Saved"];
        [MBProgressHUD hideHUDForView:self.view animated:YES];

    }
    
}

- (BOOL)shouldInvalidateLayoutForBoundsChange:(CGRect)newBounds {
    return !(CGSizeEqualToSize(newBounds.size, collectionViewOfImages.frame.size));
}

-(BOOL)shouldInvalidateLayoutForBoundsChange {
    return YES;
}









@end
