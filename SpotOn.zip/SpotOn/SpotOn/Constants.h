//
//  Constants.h
//  SpotOn
//
//  Created by Naveed Shaikh on 03/08/17.
//  Copyright © 2017 Naveed Shaikh. All rights reserved.
//

#ifndef Constants_h
#define Constants_h



//#define API_KEY  @"AIzaSyAl6N5dKNRGzWToyqR7Al5vIa5C3A2Z_t4"
#define API_KEY  @"AIzaSyBO7p_SJfM05Vtzadh5fa-KXAWzps84H-M"
#define BaseURL @"https://maps.googleapis.com/maps/api/place/"


#endif /* Constants_h */
