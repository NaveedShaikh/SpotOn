//
//  PlacedModelObject.h
//  SpotOn
//
//  Created by Naveed Shaikh on 31/07/17.
//  Copyright © 2017 Naveed Shaikh. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface PlacedModelObject : NSObject

@property (nonatomic, strong) NSString *stringPlaceReference;
@property (nonatomic, strong) NSString *stringPlaceFormattedAddress;
@property (nonatomic, strong) NSString *stringPlaceName;
@property (nonatomic, strong) NSString *stringPlaceID;


-(instancetype)initWithPlacesDetails:(NSDictionary*)dictionaryPlaces;

@end
