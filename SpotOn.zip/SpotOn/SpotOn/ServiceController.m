//
//  ServiceController.m
//  SpotOn
//
//  Created by Naveed Shaikh on 02/08/17.
//  Copyright © 2017 Naveed Shaikh. All rights reserved.
//

#import "ServiceController.h"
#import "Constants.h"


//#define API_KEY  @"AIzaSyBEFyiixLJAUj7xprcckI3lo4ZjGBbbISo"

//#define API_KEY  @"AIzaSyAl6N5dKNRGzWToyqR7Al5vIa5C3A2Z_t4"
//#define BaseURL @"https://maps.googleapis.com/maps/api/place/"

@implementation ServiceController



+(void)searchAPI:(NSString*)searchText
   forServicePath:(NSString*)servicePath
        withBlock:(void (^) (id result))success
          failure:(void (^) (NSError *error))failure {
    
    
//    NSString *ServicePath = [NSString stringWithFormat:@"https://maps.googleapis.com/maps/api/place/textsearch/json?query=%@&key=%@",[searchText stringByAddingPercentEncodingWithAllowedCharacters:[NSCharacterSet URLHostAllowedCharacterSet]],API_KEY];

    NSString *serviceURL = [BaseURL stringByAppendingString:servicePath];
    
    NSString *ServicePath = [NSString stringWithFormat:serviceURL,[searchText stringByAddingPercentEncodingWithAllowedCharacters:[NSCharacterSet URLHostAllowedCharacterSet]],API_KEY];
    
    NSURLSession *session = [NSURLSession sharedSession];
    NSURLSessionDataTask *dataTask = [session dataTaskWithURL:[NSURL URLWithString:ServicePath] completionHandler:^(NSData *data, NSURLResponse *response, NSError *error) {
        
        
        if(!error){
            success(data);
        }else
            failure(error);
    }];
    
    
    
    [dataTask resume];
    
}

// @"https://maps.googleapis.com/maps/api/place/photo?maxwidth=400&photoreference=%@&key=%@"
// @"https://maps.googleapis.com/maps/api/place/textsearch/json?query=%@&key=%@"

@end
