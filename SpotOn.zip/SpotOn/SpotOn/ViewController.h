//
//  ViewController.h
//  SpotOn
//
//  Created by Naveed Shaikh on 28/07/17.
//  Copyright © 2017 Naveed Shaikh. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

