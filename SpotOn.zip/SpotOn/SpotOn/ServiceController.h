//
//  ServiceController.h
//  SpotOn
//
//  Created by Naveed Shaikh on 02/08/17.
//  Copyright © 2017 Naveed Shaikh. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ServiceController : NSObject



+(void)searchAPI:(NSString*)searchText
   forServicePath:(NSString*)servicePath
              withBlock:(void (^) (id result))success
          failure:(void (^) (NSError *error))failure;



@end
