//
//  PlacedModelObject.m
//  SpotOn
//
//  Created by Naveed Shaikh on 31/07/17.
//  Copyright © 2017 Naveed Shaikh. All rights reserved.
//

#import "PlacedModelObject.h"

@implementation PlacedModelObject


-(instancetype)initWithPlacesDetails:(NSDictionary*)dictionaryPlaces {
    
    
    self = [super init];
    
    if (self) {
        
        
        _stringPlaceReference = [dictionaryPlaces  valueForKey:@"photo_reference"] ;
        _stringPlaceFormattedAddress = [dictionaryPlaces  valueForKey:@"formatted_address"] ;
        _stringPlaceName= [dictionaryPlaces  valueForKey:@"name"];
        _stringPlaceID= [dictionaryPlaces  valueForKey:@"place_id"];
    }
    
    return self;
    
}
@end
