//
//  imageCollectionViewCell.m
//  SpotOn
//
//  Created by Naveed Shaikh on 01/08/17.
//  Copyright © 2017 Naveed Shaikh. All rights reserved.
//

#import "imageCollectionViewCell.h"

@implementation imageCollectionViewCell


//- (UICollectionViewLayoutAttributes *)preferredLayoutAttributesFittingAttributes:(UICollectionViewLayoutAttributes *)layoutAttributes
//{
//    return layoutAttributes;
//}


@end
